package cc.ders12.adapter;

public interface ITarget {
    String faturaOlusturJSON(Fatura fatura);
}
