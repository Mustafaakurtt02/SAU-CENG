package cc.ders12.observer;

public interface IObserver {
    public void update(String m);
}
