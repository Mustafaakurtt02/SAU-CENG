package cc.ders12.proxy;

public interface IInternetBaglantisi {
    public String baglan(String url);
}
