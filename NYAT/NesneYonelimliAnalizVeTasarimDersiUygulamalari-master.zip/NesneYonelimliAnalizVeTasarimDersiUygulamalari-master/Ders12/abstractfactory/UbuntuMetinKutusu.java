package cc.ders12.abstractfactory;

class UbuntuMetinKutusu implements IMetinKutusu {
    UbuntuMetinKutusu(String arg){
        System.out.println("Ubuntu metin kutusu oluştu");
    }
    public  void mky1(){ };
    public  void mky2(){ };
}
