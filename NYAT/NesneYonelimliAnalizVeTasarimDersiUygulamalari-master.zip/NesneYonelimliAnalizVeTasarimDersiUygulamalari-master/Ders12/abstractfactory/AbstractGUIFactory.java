package cc.ders12.abstractfactory;

interface AbstractGUIFactory{
    IButon butonOlustur();
    IMetinKutusu metinKutusuOlustur();
}
