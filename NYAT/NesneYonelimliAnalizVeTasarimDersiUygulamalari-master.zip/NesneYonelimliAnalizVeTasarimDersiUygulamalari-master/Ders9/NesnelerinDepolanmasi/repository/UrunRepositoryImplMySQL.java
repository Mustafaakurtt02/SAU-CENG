package cc.ders9.nesnelerindepolanmasi.repository;

import java.util.List;

public class UrunRepositoryImplMySQL implements IUrunRepository{
    @Override
    public Urun ara(int urunNumarasi) {
        return null;
    }

    @Override
    public List<Urun> tumUrunler() {
        return null;
    }

    @Override
    public void kaydet(Urun urun) {

    }

    @Override
    public void sil(int urunNumarasi) {

    }
}
