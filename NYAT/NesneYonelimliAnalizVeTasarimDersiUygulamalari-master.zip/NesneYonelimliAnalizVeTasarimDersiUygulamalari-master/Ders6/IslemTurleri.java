package cc.ders7.atm;

public enum IslemTurleri {
    PARA_CEKME, PARA_YATIRMA, BAKIYE_GORUNTULE, CIKIS;

}
