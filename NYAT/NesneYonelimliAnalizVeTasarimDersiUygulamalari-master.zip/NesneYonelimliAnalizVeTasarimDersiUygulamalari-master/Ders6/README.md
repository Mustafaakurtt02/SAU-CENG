* ATM uygulamasının analiz aşaması sınıf şeması

![](https://github.com/celalceken/NesneYonelimliAnalizVeTasarimDersiUygulamalari/blob/master/Sekiller/06/0601.png)

* Kullanıcı doğrulama kullanım durumunun sıralama şeması

![](https://github.com/celalceken/NesneYonelimliAnalizVeTasarimDersiUygulamalari/blob/master/Sekiller/06/0602.png)

* Para Çekme kullanım durumunun sıralama şeması

![](https://github.com/celalceken/NesneYonelimliAnalizVeTasarimDersiUygulamalari/blob/master/Sekiller/06/0603.png)

* Para Çekme kullanım durumunun etkinlik şeması

![](https://github.com/celalceken/NesneYonelimliAnalizVeTasarimDersiUygulamalari/blob/master/Sekiller/06/0604.png)

## Çalışma Soruları

* Şifrenin yanlış girilme durumunu da göz önüne alacak düzenlemeyi yapınız (Etkinlik şemasına
bakınız).
* Kart bölmesi tarafından okunan hesap numarası banka bilgi sistemi tarafından doğrulansın.
* ATM de para yok ise ya da müşteri bakiyesi sıfır ise işlem hiç başlatılmasın.
* Çekilmek istenen tutar bakiyeden ya da para bölmesindeki miktardan fazla
ise yeni tutar girilmesi istensin.
* Çekilecek tutarların listesi gelsin ve kullanıcı seçebilsin.
* Para Yatırma ve Bakiye Görüntüleme kullanım durumları için sıralama ve
etkinlik şemalarını oluşturunuz.
* Para transfer işlemini ekleyiniz.
* Çekilmek istenen tutar bakiyeden ya da para bölmesindeki miktardan fazla ise yeni tutar girilmesi
istensin.
* Çekilecek tutarların listesi gelsin ve kullanıcı seçebilsin.
* Makbuz yazdırma işlemi de ele alansın.
* ATM sistemi Para Çekme işleminin haberleşme şemasını oluşturunuz.
