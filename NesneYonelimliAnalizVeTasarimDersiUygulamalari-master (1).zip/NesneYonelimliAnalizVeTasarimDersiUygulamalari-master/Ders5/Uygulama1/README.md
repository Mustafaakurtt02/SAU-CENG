## İstenenler:

* Soyut Kisi sınıfını oluşturunuz.
* Kisi sınıfından Personel ve Musteri sınıflarını türetiniz.
* Uygulama sınıfı içerisinde, çok sayıda müşteriye ait bilgileri (adresler dahil) klavyeden alınız (ilgili nesneleri oluşturunuz). Daha sonra, oluşturulan müşterilere ait bilgileri  ekrana yazdırınız.


![](https://github.com/celalceken/NesneYonelimliAnalizVeTasarimDersiUygulamalari/blob/master/Sekiller/05/UygulamaHafta5.png)


