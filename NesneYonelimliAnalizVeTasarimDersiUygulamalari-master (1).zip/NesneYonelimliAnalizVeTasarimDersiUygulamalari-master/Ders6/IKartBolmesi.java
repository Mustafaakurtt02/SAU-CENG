package cc.ders7.atm;

public interface IKartBolmesi {
    public int kartAl();
    public void kartCikart();
    public boolean kartAlindimi();
    public void kartiYut();
}
