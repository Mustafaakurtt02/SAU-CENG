package cc.ders7.atm;

public interface IIslem {
    public void islemYap();
}
