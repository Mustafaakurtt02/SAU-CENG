package cc.ders7.atm;

import java.util.Scanner;

public class TusTakimi implements ITusTakimi {

    public int veriAl() {
        Scanner input=new Scanner(System.in);
        return input.nextInt();    }
}
