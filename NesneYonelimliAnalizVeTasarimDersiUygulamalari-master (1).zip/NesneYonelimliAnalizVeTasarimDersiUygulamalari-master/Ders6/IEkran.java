package cc.ders7.atm;

public interface IEkran {
    public void mesajGoruntule(String mesaj);
    public void ekranTemizle();
}
