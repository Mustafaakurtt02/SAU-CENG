package cc.ders12.abstractfactory;

interface IMetinKutusu {
    public abstract void mky1();
    public abstract void mky2();
}
