package cc.ders12.abstractfactory;

class UbuntuButon implements IButon {
    UbuntuButon(String arg){
        System.out.println("Ubuntu butonu oluştu");
    } // Implement the code here
    public void by1() { };
    public void by2() { };
}
