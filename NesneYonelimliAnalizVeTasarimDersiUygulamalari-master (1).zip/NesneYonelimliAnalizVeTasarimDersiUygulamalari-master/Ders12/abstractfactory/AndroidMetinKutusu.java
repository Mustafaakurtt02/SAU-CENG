package cc.ders12.abstractfactory;

class AndroidMetinKutusu implements IMetinKutusu {
    AndroidMetinKutusu(String arg){
        System.out.println("Android metin kutusu oluştu");
    }
    public  void mky1(){ };
    public  void mky2(){ };
}
