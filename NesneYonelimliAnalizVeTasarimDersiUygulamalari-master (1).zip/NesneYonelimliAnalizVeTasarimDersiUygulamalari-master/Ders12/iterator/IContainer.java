package cc.ders12.iterator;

public interface IContainer {
    public IIterator getIterator();
}
