package ilkuygulama;

/**
* ilkuygulama.IlkUygulama.java olarak kaydedilmeli.
*
*/

public class IlkUygulama 
{
    public static void main(String[] s) {
        // Merhaba Dünya ifadesi çıkış konsoluna (ekrana) yönlendiriliyor   
        System.out.println("Merhaba Dünya");
    }
}