package cc.ders12.factory.uygulama2;



interface IButonFactory {
    public IButon factoryMethod();
}
