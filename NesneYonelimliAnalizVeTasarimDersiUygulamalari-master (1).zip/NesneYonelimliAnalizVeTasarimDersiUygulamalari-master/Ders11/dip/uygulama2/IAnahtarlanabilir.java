package cc.ders10.dip.uygulama2;

public interface IAnahtarlanabilir {
    void ac();
    void kapat();

}
