package cc.ders10.dip.uygulama1;

public class Lamba {
    public void isigiYak(){
        System.out.println("ışık yanıyor");
    }

    public void isigiKapat(){
        System.out.println("ışık kapandı");
    }
}
