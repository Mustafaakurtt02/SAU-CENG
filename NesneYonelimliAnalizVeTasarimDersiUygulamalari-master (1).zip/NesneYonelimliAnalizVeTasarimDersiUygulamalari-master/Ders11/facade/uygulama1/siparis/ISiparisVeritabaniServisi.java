package cc.ders12.facade.uygulama1.siparis;

public interface ISiparisVeritabaniServisi {

    public void siparisiKaydet(Siparis siparis);


}
