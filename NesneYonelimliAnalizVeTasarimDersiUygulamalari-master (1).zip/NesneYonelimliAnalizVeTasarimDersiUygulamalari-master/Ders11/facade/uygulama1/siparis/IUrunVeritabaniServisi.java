package cc.ders12.facade.uygulama1.siparis;

import java.util.List;

public interface IUrunVeritabaniServisi {
    public List<Urun> urunListele();

    //Urun urunBul();
}
