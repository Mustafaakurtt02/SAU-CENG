package cc.ders10.lsp.uygulama2;

public interface ISekil {
    public double alanHesapla();
}
