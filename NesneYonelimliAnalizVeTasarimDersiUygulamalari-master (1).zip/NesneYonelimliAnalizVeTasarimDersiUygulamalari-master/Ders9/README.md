# Java ile Veritabanı(PostgreSQL) İşlemleri

PostgreSQL jdbc sürücüsü https://jdbc.postgresql.org/download.html bağlantısından indirilebilir.

Sürücüler aşağıdaki temel fonksiyonları sağlar:

* bağlantı kurulumu
* sorgu çalıştırma
* bağlantı sonlandırma

Java ile veratabanı işlemleri için gerekli ortamın hazırlanması:
* https://youtu.be/aPEx1RexoCY
