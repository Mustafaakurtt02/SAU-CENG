package cc.ders9.nesnelerindepolanmasi.siparis;

public interface ISiparisRepository {

    public void siparisiKaydet(Siparis siparis);


}
